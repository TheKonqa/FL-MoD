================================================================================
== CONFIG ======================================================================
================================================================================
take a look at the comments in FLHook.ini

================================================================================
== ADMIN-COMMANDS ==============================================================
================================================================================
commands can be executed by administrators in several ways:
- using the FLHook console(-> access to all commands)
- ingame by typing .command in the chat(e.g. .getcash Player1)
  this will only work when you own the appropriate rights which may be set via
  the setadmin command. FLHook will store the rights of each player in his
  account-directory in flhookadmin.ini.
- via a socket connection in raw text mode(e.g. with putty)
  connect to the port given in the FLHook.ini and enter "PASS password". after
  having successfully logged in you may enter all of the commands you want(as
  long as you have the necessary rights). you may have several socket connections
  at the same time. exiting the connection may be done by entering "quit" or simply
  by closing it.

- CASH -
all cash functions work no matter if the player is currently logged in or not
getcash <charname>
  shows current account balance of <charname>
setcash <charname> <amount>
  sets current account balance of <charname> to <amount>
setcashsec <charname> <oldmoney> <amount>
  sets current account balance of <charname> to <amount>, only works when his old account balance is <oldmoney>
addcash <charname> <amount>
  adds <amount> to the current account balance of <charname>
addcashsec <charname> <oldmoney> <amount>
  adds <amount> to the current account balance of <charname>, only works when his old account balance is <oldmoney>

- KICK/BAN -
kick <charname> <reason>
  disconnects <charname>. the user will be displayed <reason>, if it is specified.
ban <charname>
  bans <charname>'s account
  <charname> stays connected if he's currently on the server
unban <charname>
  unbans <charname>'s account
kickban <charname> <reason>
  kicks and bans <charname> (2 in 1, same as kick <charname> <reason>, ban <charname>)

- MSG -
msg <charname> <text>
  private message <text> to <charname> (shown as "Console: <text>")
msgs <systemname> <text>
  send <text> to all players in <systemname> (shown as "Console: <text>")
  <systemname> must be the either the system-id or the shortname (like Li01)
msgu <text>
  message <text> to the whole universe
msguc <text>
  message <text> to the whole universe (shown as "Console: <text>")
fmsg <charname> <xmltext>
  private message <xmltext> to <charname> (see XMLTEXT section for further details)
fmsgs <systemname> <xmltext>
  send <xmltext> to all players in <systemname> (see XMLTEXT section for further details)
fmsgu <xmltext>
  message <xmltext> to the whole universe (see XMLTEXT section for further details)

- BEAM/KILL -
beam <charname> <basename>
  force <charname> to land on <basename> (player must be in space)
  <basename> must be either the shortname(like Li01_01_Base for Manhattan) or a shortcut defined in the FLHook.ini
  Player may be kicked after beam
  note: see the issues section below
kbeam <charname> <basename>
  Kills <charname>, respawning them at <basename> when they click RESPAWN
  As long as the player respawns after dying, they will not lose any cargo
  This is meant as a replacement for beam, which sometimes kicks a player
kill [charname]
  kills [charname] if it is defined, otherwise kills object selected in HUD
instantdock <charname>
  Instantly docks <charname> to the selected object in HUD; note that the object and <charname> must be in the same system

- REPUTATION -
resetrep <charname>
  sets <charname>'s reputations to the one specified in "mpnewcharacter.fl"
setrep <charname> <repgroup> <value>
  set <charname>'s reputation for <repgroup> to <value>. <value> should be between -1 and 1.
  example:
  "setrep playerxy li_n_grp 0.7"
  -> set playerxy's reputation for liberty navy to 0.7
setreprelative <charname> <repgroup> <value>
  Adjust <charname>'s reputation with <repgroup> by <value>.
  Works like when you kill a NPC - the reps with all the other factions are adjusted as well.
getrep <charname> <repgroup>
  get <charname>'s reputation for <repgroup>.
  getrep playerxy li_n_grp returns "rep=0.1223", for example.
getaffiliation <charname>
  gets <charname>'s affiliation; returns "repgroup=li_n_grp", for example.
setaffiliation <charname> <repgroup>
  sets <charname>'s affiliation

- CARGO -
All cargo commands except for addcargo only work when the targeted player is ingame
enumcargo <charname>
  lists <charname>'s cargo, first reply will be the remaining hold size
addcargo <charname> <good> <count> <mission>
  adds <count> numbers of <good>(shortname like co_gun01_mark02,commodity_silver,etc OR hash) to <charname>'s cargo
  if <mission> is set to 1, the cargo is declared as mission cargo
addcargom <charname> <good> <hardpoint> <mission>
  Same as above except the cargo is mounted to <hardpoint>.
removecargo <charname> <id> <count>
  removes <count> numbers of <id>(this must be the value from enumcargo's "id=" reply) from <charname>

- CHARACTERS -
rename <oldcharname> <newcharname>
  rename <oldcharname> to <newcharname> (player will be kicked if he's logged in <oldcharname>'s account)
deletechar <charname>
  delete <charname> (player will be kicked if he's logged in <oldcharname>'s account)
readcharfile <charname>
  reads <charname>'s userfile(xxx.fl) and prints it(each line will be preceded by "l ")
writecharfile <charname> <data>
  writes <data> into <charname>'s userfile(xxx.fl). existing charfile will be overwritten. you should
  be careful with this one because a corrupted charfile may lead to server crashes and flhook does 
  not do any syntax checks on <data>.
  NOTE: YOU MUST REPLACE LINE-WRAPS WITH \n(TEXT)
  example:
  writecharfile playerxy [Player]\ndescription = 00300034002f0031003\n\n ... etc.

- SETTINGS -
setadmin <charname> <rights>
  set <charname> as ingame-admin with <rights> (affects all characters on the account) (see RIGHTS section below)
getadmin <charname>
  show <charname>'s rights
deladmin <charname>
  revoke <charname>'s ingame-admin-status
setadminrestriction <charname> <restriction>
  Only allow <charname> to execute admin commands on characters with names that include <restriction>.
getadminrestriction <charname>
  Gets the admin restriction for <charname>; returns "restriction=[blarg]", for example.
rehash
  reload the flhook.ini in order to activate changed settings, this works for everything except the socket-settings
unload
  unload flhook(flserver will keep on running flawlessly)
  this is very useful since it allows you to install a new flhook version on-the-fly. simply unload, replace the files
  and execute FLHookStart.exe
  the command will kick players with an active moneyfixlist(don't bother).

- GROUP -
getgroupmembers <charname>
  returns all players which are in a group with <charname>
getgroup <charname>
  gets the group-id of <charname>; returns "groupid=2", for example.
  players in no group have a group-id of 0.
addtogroup <charname> <group>
  adds <charname> to <group>
invitetogroup <charname> <fromcharname>
  invites <charname> to join <fromcharname>'s group
removefromgroup <charname> <group>
  removes <charname> from <group>
sendgroupcash <group> <amount>
  sends everyone in <group> <amount> of cash, divided among the members

- DEATH PENALTY -
These commands require both cash and cargo rights.
setdpfraction <decimal amount>
  Sets the death penalty fraction
adddpsystem <systemname>
  Add a system to the death penalty exclusion list
removedpsystem <systemname>
  Remove a system from the death penalty exclusion list
enumdpsystems
  Print all systems on the death penalty exclusion list
  
- OTHER -
getbasestatus <basename>
  returns the hull status of a base. when the base hasn't been created in space yet it returns 0.
getclientid <charname>
  gets <charname>'s client id
getplayerinfo <charname>
  get <charname>'s info
xgetplayerinfo <charname>
  same as getplayerinfo, except that result is shown in a more readable format
getplayers
  get player info for all players on the server (players in charselect menu will not be shown)
xgetplayers
  same as getplayers, except that result is shown in a more readable format
getplayerids
  shows all players on the server with their client-id in a short format(useful when ingame)
getaccountdirname <charname>
  get account-dirname of <charname>
getcharfilename <charname>
  get char-filename of <charname>
savechar <charname>
  save <charname>'s current info to disk
isloggedin <charname>
  check if <charname> is logged in on the server
isonserver <charname>
  check if <charname> is connected(this includes idleness in charselect menu) to the server
  NOTE: isonserver will also return true, when another char on the same account is logged in!
serverinfo
  shows server load, whether npc spawn is currently enabled or disabled(see ini) and uptime.
  the format for the uptime is: days:hours:minutes:seconds
moneyfixlist
  show players with active money-fix
restartserver
  restart the server; command line params can be set in ini.  NOTE: will create an instance 
  of cmd.exe, which will exit when the server does; requires that the server have
  taskkill installed (is not installed by default on XP Home).
shutdownserver
  shutdown the server.  NOTE: requires that the server have taskkill installed (is not installed
  by default on XP Home).
spawns [on|off]
  Turns NPC spawns on or off.
help [page number (if ingame)]
  get a list of all commands
  
- MISC INFOS -
you can use client-ids instead of <charname> by appending $ to the cmd.  Using $ for the client-id means use your own.
examples: 
getcash$ 12
kickban$ 1
getplayerinfo$ $
etc.

you can also use "shortcuts" instead of the whole character-name for a currently logged in player by appending
& to the cmd. FLHook traverses all logged in players and checks if their character-name contains
<charname>(case insensitive) and if so, the command will operate on this player. an error will be shown if the 
searchstring given in <charname> is ambiguous.
examples (let's assume there are 2 players logged in: "superhax0r" and "..::[]SUPERNERD[]::.."):
"kick& nerd" kicks "..::[]SUPERNERD[]::.." because his nick contains "nerd"
"getcash& super" fails because there are multiple character names containing "super"

all commands return "OK" when successful or "ERR <errortext>" when error occured

================================================================================
== RIGHTS ======================================================================
================================================================================
rights may be separated by a comma (e.g. setadmin playerxy cash,kickban,msg)
superadmin        -> everything
cash              -> cash commands
kickban           -> kick/ban/group commands
beam              -> beam/kill/resetrep/setrep command
msg               -> msg commands
savechar          -> savechar command
cargo             -> cargo commands
chars             -> rename/deletechar/readcharfile/writecharfile
eventmode         -> eventmode (only when connected via socket)
all other commands except setadmin/getadmin/deladmin/restartserver/shutdownserver/spawns may be executed by all admins

================================================================================
== XMLTEXT =====================================================================
================================================================================

the fmsg* commands allow you to format text in several ways(like in the exe\misctext.dll)
text is enclosed in <TEXT></TEXT> tags while the format can be changed with <TRA .../>
nodes-names must be written in capital chars! 
be sure to replace the following characters within a text-node:
< -> &#60; 
> -> &#62;
& -> &#38;

- <TRA .../> NODE SYNTAX -
the data field of a TRA node consists of an RGB value along with format specifications:
<TRA data="0xBBGGRRFF" mask="-1"/>
BB is the blue value
GG is the green value
RR is the red value
FF is the format value
(all in hexadecimal representation)

format flags are:
bin      hex  dec  effect
00000001 1    1    bold
00000010 2    2    italic
00000100 4    4    underline
00001000 8    8    big
00010000 10   16   big&wide
00100000 20   32   very big
01000000 40   64   smoothest?
10000000 80   128  smoother?
10010000 90   144  small
simply add the flags to combine them (e.g. 7 = bold/italic/underline)

examples:
fmsgu <TRA data="0x1919BD01" mask="-1"/><TEXT>A player has died: Player</TEXT>
this is similar to the standard die-msg(which is shown in bold)
fmsgu <TRA data="0xFF000003" mask="-1"/><TEXT>Hello</TEXT><TRA data="0x00FF0008" mask="-1"/> <TEXT>World</TEXT>
this will show "Hello World" ("Hello" will be blue/bold/italic and "World" green/big)

================================================================================
== EVENTMODE ===================================================================
================================================================================
socket connections may be set to eventmode by entering "eventmode". from then on 
you will receive several event-notifications listed below. once activated, 
eventmode runs until you close the connection.

- NOTIFICATIONS -
chat from=<player> id=<client-id> type=<type> [to=<recipient> idto=<recipient-client-id>] text=<text>
  <player>: charname sending the message
  <client-id>: client-id of sender
  <type>: either universe,system or player
  <recipient>/<recipient-client-id>: only sent when type=player
  <text>: guess ...

kill victim=<player> by=<killer1>[,<killer2]... cause=<killer1's weapons>[;killer2's weapons]...
  <player>: charname of the victim.
  <killerx>: charname/faction(if NPC) of the killer; sorted from highest to lowest damage.
  <killerx's weapons>: comma separated list of weapons used to kill player.  Weapons can be guns, missiles (only if CombineMissilesTorps is set to no), mines, torpedoes (only if CombineMissilesTorps is set to no), missiles/torpedoes (only if CombineMissilesTorps is set to yes), or collisions.  Sorted from highest to lowest damage.

login char=<player> accountdirname=<dirname> id=<client-id> ip=<ip>
  occurs when player selects a character in the character-select menu

launch char=<player> id=<client-id> base=<basename> system=<systemname>
  occurs when player undocks from a base/planet

baseenter char=<player> id=<client-id> base=<basename> system=<systemname>
  occurs when player enters base
  
baseexit char=<player> id=<client-id> base=<basename> system=<systemname>
  occurs when player exits base(includes disconnect/f1)

jumpin char=<player> id=<client-id> system=<systemname>
  occurs when player jumps in a system
  
switchout char=<player> id=<client-id> system=<systemname>
  occurs when player switches out a system

spawn char=<player> id=<client-id> system=<systemname>
  occurs when player selects a character and launches in space

connect id=<client-id> ip=<ip>
  occurs when player connects to the server

disconnect char=<player> id=<client-id>
  occurs when player disconnects from the server

================================================================================
== USER-COMMANDS ===============================================================
================================================================================
user commands may be entered ingame by every player in chat and can be enabled
or disabled in the ini. enter them ingame to get a description.

/set diemsg xxx
  while xxx must be one of the following values:
  - all = all deaths will be displayed
  - system = only display deaths occurring in the system you are currently in
  - self = only display deaths the player is involved in(either as victim or killer)
  - none = don't show any death-messages
  settings keep saved in flhookuser.ini and affect all characters on the account

/set diemsgsize <small/default>
  - change the size of the diemsgs

/set chatfont <size> <style>
  <size>: small, default or big
  <style>: default, bold, italic or underline
  this lets every user adjust the appearance of the chat-messages

/autobuy <on|off>
  - on: saves the current configuration of unmounted items and attempts to
  complete that configuration upon entering a base.
  - off: deletes the current configuration.

/ignore <charname> [<flags>]
  ignore chat from certain players

/ignoreid <client-id> [<flags>]
  ignore by client-id
  
/delignore <id> [<id2> <id3> ...]
  delete ignore entry
  
/ignorelist
  display ignore list
  
/ignoreuniverse <on|off>
  Ignores chat from the universe channel

/ids
  show client-ids of all players

/id
  show own client-id
  
/i$ <client-id> and /invite$ <client-id>
  invite player to group by client-id

/cloak and /c
  Cloak the ship if a cloaking device is present on it.
  If used when cloaked, shows the time remaining for the cloak.

/uncloak and /uc
  Uncloak the ship if it is cloaked.

/rename <new name>
  Renames the logged-in character to the new name.  Costs an amount of credits set in the ini.

/sendcash <charname> <amount>
  Sends <amount> of credits to <charname>.  Charges a tax set in the ini to the sender.

/sendcash$ <client-id> <amount>
  Same as above but with client-id.
  
/afk [Message]
  Sets away from keyboard message, which is automatically sent to people who message you.
  The default message is "I'm away from my keyboard right now."
  If no message is appended to the command and AFK is set, then AFK is unset; 
  otherwise the message is updated with the new message specified.
  
/inviteall [name part] and /ia [name part]
  Invites all players on server to join into a group with you.
  If [name part] is present, it only invites those who have [name part] in their name.

/shieldsdown and /sd
  Makes the shields on your ship fail.
  
/shieldsup and /su
  Makes the shields on your ship recharge to the levels they were at when the shields
  down command was used.  Note that it will not make your shields go up instantly.
  
/mark and /m
  Makes the selected object appear in the important section of the contacts and
  have an arrow on the side of the screen, as well as have > and < on the sides
  of the selection box.
  
/unmark and /um
  Unmarks the selected object marked with the /mark (/m) command.
  
/groupmark and /gm
  Marks selected object for the entire group.
  
/groupunmark and /gum
  Unmarks the selected object for the entire group.
  
/ignoregroupmarks <on|off>
  Ignores marks from others in your group.
  
/automark <on|off> [radius in KM]
  Automatically marks all ships in KM radius.  Bots are marked automatically in the
  range specified whether on or off.  If you want to completely disable automarking,
  set the radius to a number <= 0.
  
/botcombat <on|off>
  Turns your bots (AI Companion option) hostile to you for combat purposes.
  
/dock and /d
  Docks your ship at a valid player ship, allowing you to repair and buy equipment
  as with a normal base.
  
/transfer <charname> <item>
  Transfers <item> to <charname>.  Valid items are those that are not grouped
  (like commodities and ammo).  Charges a price set in the ini to the sender.

/transfer$ <client-id> <item>
  Same as above but with client-id.
  
/enumcargo
  Prints out a number for each cargo item that can be used with the /transfer command.

/dp [on|off]
  Shows information about the death penalty.  Also sets whether a notice about how
  much the death penalty costs is shown upon launch.
  
/tag <faction>
  Changes your affiliation to <faction>, making it appear beside your name ingame.
  
/help [command] and /? [command]
  If command is not specified, prints out list of commands.  If it is specified,
  prints out information on command.

================================================================================
== SPECIAL FEATURES ============================================================
================================================================================
- Cloak by w0dk4: adds a balanced cloaking system to FLHook. Cloaking devices 
  and cloaking times are defined in the ini under [CloakDevices].
- Repair guns: guns that repair instead of damage ships and solars. They are 
  defined in the ini under [RepairGuns].
- Alternate base repairing: bases whose hit points match the list defined under
  [BaseRepair] in the ini are not repaired for the first half the time set and 
  then are repaired completely during the second half of the set time. The time 
  can be set in the ini under [General]; it is 240 seconds by default.  If the
  base is killed while being repaired the cycle restarts at the end of the set
  time.  The base can only be repaired by its hit points, so if it is damaged
  while being repaired it will not be repaired all the way.
- Automatic changing of affiliation: when the mountable faction tags present in
  the 88 Flak mod are bought from a base and are mounted automatically after 
  being bought, the affiliation of the player who bought the tag is changed to
  that of the tag. Note that for this to work the nickname of the faction tag 
  must have "_grp_token" in it, be the nickname of the faction it represents 
  with a "_token" appended to it, and be defined in misc_equip.ini.
- Mobile docking: allows players to dock with other players.  The valid ships
  can be set under [MobileBases] in the ini.  Ships cannot dock with other ships
  on the list.  In order for mobile docking to function, there must be a base in
  every system with a nickname and base name of <system nick>_mobile_proxy_base.
  Players will be instantly docked at this base when /dock (/d) is executed on a
  valid ship and that ship is in range (settable in ini under 
  [General]->MobileDockRadius).  The distance under or over the carrier the
  player is launched at can be configured in the ini under
  [General]->MobileDockOffset.  Players must be in the same group in order to dock.

================================================================================
== KNOWN ISSUES ================================================================
================================================================================
- crashes/performance:
  FLHook is very resistant to server crashes. we've had it running on hhc for
  weeks without any major problems. however in case you encounter any crashes
  which are obviously related to FLHook please contact me.
- the standard beam command can cause the server to crash.  This is why this
  version of FLHook has a setting allowing configuration of the .beam command.
  By default it is set to use the improvements made by w0dk4 in the plugin
  version.  Look at [General]->BeamCmdBehavior for the setting and more
  information.
- the sender in the standard chat messages appear a little bit smaller when
  "/set chatfont" is enabled
- calculation of the "loss" has been improved but is still problematic. players with
  low bandwidth tend to have a very high loss while they're loading, so this may
  lead to some problems. i don't recommend using the loss-kick at this moment.

================================================================================
== SOURCE CODE =================================================================
================================================================================
FLHook compiles on both vc7 and vc6
Note:
flserver uses string-class arguments in some of its functions(f. e. 
PlayerDB::FindAccountFromCharacterName(...)). when you compile since FLHook with 
vc7, which uses a different stl, you can't simply pass strings. that's why
i created the FLHookWString.dll which was compiled with vc6 and just exports
two functions to create/delete flserver compatible strings. if you don't have
vc6 installed then use the FLHookWString.dll from bin and thats it.

if you want the full header files/libs of all of the relevant flserver dlls then 
take a look at FLCoreSDK(www.skif.be). it contains everything you need.
Since www.skif.be has disappeared, w0dk4 has mirrored the DL at
http://aa-flserver.de/download/FLCoreSDK.zip .

please note:
I WILL NOT TEACH YOU HOW TO CODE, I WILL NOT TELL YOU HOW TO REVERSE FLSERVER 
AND I WILL NOT REPLY TO "STUPID" QUESTIONS REGARDING THE SOURCE - mc_horst
w0dk4 and M0tah however are generally willing to try and answer questions regarding
the source/FLHook in general.  The FLHook forum can be found at
http://flhook.drachennest200x.de/forum/ .

================================================================================
== BLOWFISH ENCRYPTION PROGRAMMING =============================================
================================================================================
Because Blowfish only supports encrypting 8 bytes of data at once, it is
necessary to pad data (with 0x00s) that is not a multiple of 8 bytes.  When
recieving encrypted data from FLHook, you should check for null characters and
remove them from the decrypted string.  When sending encrypted data to FLHook,
you should pad the string with null characters if necessary.  If the blowfish
implementation you are using specifically encrypts and decrypts strings, this
may already be handled by it.

================================================================================
== CREDITS =====================================================================
================================================================================
unofficial builds after 1.5.5 programmed and documented by M0tah
Thanks to w0dk4 for answering questions I've had regarding hooks and other things
pertinant to FLHook and for coding a fix for the beam command - M0tah
Anti-Superjump code taken from http://flhook.drachennest200x.de/forum/viewtopic.php?t=11,
thanks to Reaper.
PlayerDB struct update taken from http://flhook.drachennest200x.de/forum/viewtopic.php?t=344,
thanks to Devast8or.
Beam command fix taken from the plugin version, programmed by w0dk4.  It can be
found at http://the-starport.net/index.php?option=com_smf&Itemid=26&topic=523.0 .
w0dk4's socket buffer overflow fix has also been implemented.

programmed & documented by mc_horst
BIG THX to w0dk4 and Niwo for testing and the whole Hamburg City Server adminteam 
for the suggestions and feedback

contact: find me on www.freelancerserver.de or #hc-flserver (quakenet)

FLHook uses a slightly modified version of flcodec.c

Blowfish encryption was implemented using the C algorithm by Paul Kocher,
downloaded from http://www.schneier.com/blowfish-download.html